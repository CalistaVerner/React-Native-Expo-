import { useMemo, useState } from 'react';
import type { Session } from '../config/sessions';

export function useSessionSelection(sessions: Session[]) {
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);

  const selectedSession = useMemo(
    () => sessions.find((session) => session.id === selectedSessionId) ?? null,
    [sessions, selectedSessionId]
  );

  return {
    selectedSessionId,
    selectedSession,
    selectSession: (session: Session) => setSelectedSessionId(session.id),
  };
}
