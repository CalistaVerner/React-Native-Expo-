import React from 'react';
import { Text, View } from 'react-native';
import type { AppTheme } from '../../../shared/theme/themes';
import { SelectBox } from '../../../shared/ui/SelectBox';
import { SurfaceCard } from '../../../shared/ui/SurfaceCard';
import { SectionHeader } from '../../../shared/ui/SectionHeader';
import type { PreferenceSectionModel } from '../model/preferenceFields';
import { preferenceSectionCardStyles } from './styles/preferenceSectionCard.styles';

export function PreferenceSectionCard({
  theme,
  section,
}: {
  theme: AppTheme;
  section: PreferenceSectionModel;
}) {
  return (
    <SurfaceCard theme={theme} style={preferenceSectionCardStyles.card}>
      <SectionHeader theme={theme} title={section.title} caption={section.caption} compact />
      <View style={preferenceSectionCardStyles.fieldStack}>
        {section.fields.map((field) => (
          <View key={field.key} style={preferenceSectionCardStyles.fieldBlock}>
            <SelectBox
              theme={theme}
              label={field.title}
              modalTitle={field.modalTitle}
              options={field.options}
              value={field.value}
              onChange={field.onChange}
            />
            {field.description ? (
              <Text style={[preferenceSectionCardStyles.description, { color: theme.colors.textMuted }]}>
                {field.description}
              </Text>
            ) : null}
          </View>
        ))}
      </View>
    </SurfaceCard>
  );
}
