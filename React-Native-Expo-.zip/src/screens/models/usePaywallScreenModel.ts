import { useMemo } from 'react';
import { useAppContext } from '../../app/state/AppContext';
import { buildPaywallPlanCards } from '../../features/subscription/lib/planPresentation';
import { FEATURE_FLAGS } from '../../shared/config/featureFlags';

export function usePaywallScreenModel() {
  const {
    theme,
    t,
    selectedPlan,
    setSelectedPlan,
    setIsSubscribed,
    setScreen,
    regionCode,
    monthlyPrice,
    yearlyPrice,
    yearlySavings,
    detectedCurrencyCode,
  } = useAppContext();

  const plans = useMemo(
    () =>
      buildPaywallPlanCards({
        t,
        selectedPlan,
        monthlyPrice,
        yearlyPrice,
        yearlySavings,
      }),
    [t, selectedPlan, monthlyPrice, yearlyPrice, yearlySavings]
  );

  return {
    theme,
    t,
    regionCode,
    detectedCurrencyCode,
    plans,
    flags: FEATURE_FLAGS.paywall,
    setSelectedPlan,
    onTryFree: () => {
      setIsSubscribed(true);
      setScreen('meditations');
    },
    onContinueFree: () => setScreen('meditations'),
  };
}
