import { useMemo } from 'react';
import { useAppContext } from '../../app/state/AppContext';
import { buildPreferenceSections } from '../../features/settings/config/preferenceSections';
import { FEATURE_FLAGS } from '../../shared/config/featureFlags';

export function usePreferencesScreenModel() {
  const {
    theme,
    t,
    language,
    languagePreference,
    setLanguagePreference,
    themePreference,
    setThemePreference,
    regionPreference,
    setRegionPreference,
    regionCode,
    monthlyPrice,
    yearlyPrice,
    fxSnapshotDate,
    isSubscribed,
    setIsSubscribed,
    setScreen,
    resetPreferences,
  } = useAppContext();

  const sections = useMemo(
    () =>
      buildPreferenceSections({
        t,
        language,
        regionCode,
        languagePreference,
        themePreference,
        regionPreference,
        setLanguagePreference,
        setThemePreference,
        setRegionPreference,
      }),
    [
      t,
      language,
      regionCode,
      languagePreference,
      themePreference,
      regionPreference,
      setLanguagePreference,
      setThemePreference,
      setRegionPreference,
    ]
  );

  return {
    theme,
    t,
    sections,
    flags: FEATURE_FLAGS.preferences,
    monthlyPrice,
    yearlyPrice,
    fxSnapshotDate,
    isSubscribed,
    toggleSubscribed: () => setIsSubscribed(!isSubscribed),
    resetPreferences: () => void resetPreferences(),
    backToMeditations: () => setScreen('meditations'),
  };
}
