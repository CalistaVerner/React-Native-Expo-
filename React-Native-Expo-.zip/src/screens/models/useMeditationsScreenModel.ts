import { useMemo } from 'react';
import { useAppContext } from '../../app/state/AppContext';
import { useAffirmationController } from '../../features/affirmation/lib/useAffirmationController';
import { SESSIONS } from '../../features/meditations/config/sessions';
import { useSessionSelection } from '../../features/meditations/lib/useSessionSelection';
import { FEATURE_FLAGS } from '../../shared/config/featureFlags';

export function useMeditationsScreenModel() {
  const { theme, t, isSubscribed, setScreen, regionCode, language } = useAppContext();
  const affirmation = useAffirmationController(language);
  const selection = useSessionSelection(SESSIONS);

  const librarySessions = useMemo(() => SESSIONS, []);

  return {
    theme,
    t,
    isSubscribed,
    regionCode,
    flags: FEATURE_FLAGS.meditations,
    librarySessions,
    affirmation,
    selection,
    openSettings: () => setScreen('preferences'),
    openPaywall: () => setScreen('paywall'),
  };
}
