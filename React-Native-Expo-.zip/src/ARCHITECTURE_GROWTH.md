# ZenPulse architecture growth points

## 1. Screen models

Each screen evolves through a dedicated view-model layer:
- `screens/models/usePaywallScreenModel.ts`
- `screens/models/useMeditationsScreenModel.ts`
- `screens/models/usePreferencesScreenModel.ts`

This keeps React Native markup thin and turns future product changes into data-shaping work instead of screen rewrites.

## 2. App preferences runtime is isolated

`app/state/useAppPreferences.ts` owns:
- hydration
- persistence
- device locale refresh
- theme/language/region resolution
- localized price derivation

That lets `AppContext` stay focused on composition instead of becoming the entire application runtime.

## 3. Preference sections are data-driven

Preferences no longer hardcode each field inside the screen.

`features/settings/config/preferenceSections.ts` defines:
- section grouping
- field metadata
- option providers
- update handlers

To add a future preference such as voice pack, AI tone, notification profile, playback style, or haptics mode, add it to section config and reuse the same UI card.

## 4. Subscription presentation is centralized

`features/subscription/lib/planPresentation.ts` is now the single place where paywall plan cards are derived.

This makes it easier to:
- add more plans
- experiment with pricing presentation
- introduce regional promotional states
- drive paywall A/B variants from data

## 5. Meditation runtime is split by responsibility

Meditations uses separate controller hooks:
- `useAffirmationController` for AI state and generation flow
- `useSessionSelection` for library selection state

This creates a clean base for:
- provider-based AI generation
- session-to-affirmation personalization
- recently played / recommended / bookmarked tabs
- analytics events without polluting screens

## 6. Feature flags define safe growth edges

`shared/config/featureFlags.ts` controls optional product modules such as:
- prompt preview visibility
- library selection summary
- pricing preview cards
- demo subscription state
- paywall metadata blocks

This is a lightweight foundation for:
- demo vs production profiles
- A/B experiments
- staged rollouts
- disabling unstable modules without rewriting screens

## 7. Shared section and surface composition

The project already has reusable surface/select/select-box primitives. The next growth path is to keep screens declarative and let feature configuration drive layout and visibility.
